function drawline(IX, IY, FX,FY){
	var punteado = 5;
	//El inicio de todas las lineas sera en el origen (translate(centro))
	//for(){

	//}
	line(0, 0, FX, FY);
}

function drawcircle(X,Y,radio){
	//rgba(255,255,255,0.75);

	ellipse(X, Y, radio);
}